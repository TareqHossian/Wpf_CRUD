﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace WpfAppCrud
{
    
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadGrid();
        }
        SqlConnection con=new SqlConnection("Data Source=DESKTOP-G18H3U1;Initial Catalog=WpfDB;Integrated Security=True");
        public void ClearData()
        {
            name_txt.Clear();
            age_txt.Clear();
            gender_txt.Clear();
            city_txt.Clear();
            search_txt.Clear();
        }
        public void LoadGrid()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM FirstTable", con);
                DataTable dt = new DataTable();
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr != null)
                {
                    dt.Load(sdr);
                    datagrid.ItemsSource = dt.DefaultView;
                }

                con.Close();
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("An error occurred while loading the grid: " + ex.Message, "Error");
            }
        }
        public bool isValid()
        {
           
            
                if (name_txt.Text == string.Empty)
                {
                    MessageBox.Show("Name required","Faild",MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }

                if (age_txt.Text == string.Empty)
                {
                    MessageBox.Show("Name required", "Faild", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }

                if (gender_txt.Text == string.Empty)
                {
                    MessageBox.Show("Name required", "Faild", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }

                if (city_txt.Text == string.Empty)
                {
                    MessageBox.Show("Name required", "Faild", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
               return true;


        }
        

        private void ClearBtn_Click(object sender, RoutedEventArgs e)
        {
            ClearData();
        }

       
        private void InsertBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (isValid())
                {
                    SqlCommand cmd = new SqlCommand("Insert into FirstTable (Name, Age, Gender, City, ImagePath) Values(@Name, @Age, @Gender, @City, @ImagePath)", con);
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@Name", name_txt.Text);
                    cmd.Parameters.AddWithValue("@Age", age_txt.Text);
                    cmd.Parameters.AddWithValue("@Gender", gender_txt.Text);
                    cmd.Parameters.AddWithValue("@City", city_txt.Text);
                    cmd.Parameters.AddWithValue("@ImagePath", imagePath);  

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    LoadGrid();
                    MessageBox.Show("Successfully registered", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
                    ClearData();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void datagrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from firstTable where ID=" + search_txt.Text + " ", con);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Has been deleted","Deleted",MessageBoxButton.OK, MessageBoxImage.Error);
                con.Close();
                ClearData();
                LoadGrid();
                con.Close();
;
            }
            catch (SqlException ex)
            {

                MessageBox.Show("Not Deleted"+ex.Message);
            }
            finally { con.Close(); }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void UpdateBtn_Click(object sender, RoutedEventArgs e)
        {
            con.Open();
            SqlCommand cmd=new SqlCommand("update firstTable set Name='"+name_txt.Text+"',Age='"+age_txt.Text+"',Gender='"+gender_txt.Text+ "',City='"+ city_txt.Text+"' where ID='"+search_txt.Text+"'",con);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successully updated","Updated",MessageBoxButton.OK,MessageBoxImage.Error);
            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally {
                con.Close();
                ClearData() ;
                LoadGrid();
            }
        }

        private string imagePath;  

        private void UploadImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files|*.jpg;*.jpeg;*.png;*.gif|All files|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
           
                ImagePreview.Source = new BitmapImage(new Uri(openFileDialog.FileName));
                imagePath = openFileDialog.FileName; 
            }
        }

        private void gender_txt_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
